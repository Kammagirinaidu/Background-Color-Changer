
function changeColor(){
let letters="0123456789ABCDEF";
let color="#";

for(let i=0;i<6;i++){
color+=letters[Math.floor(Math.random()*16)];
}

document.body.style.background=color;
document.getElementById("colorCode").textContent="Color: "+color;
}
